-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 09, 2022 at 08:21 AM
-- Server version: 10.3.16-MariaDB
-- PHP Version: 7.3.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_bursa_smk`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id_admin` int(11) NOT NULL,
  `username` varchar(10) NOT NULL,
  `password` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id_admin`, `username`, `password`) VALUES
(2, 'lppm123', '123456r');

-- --------------------------------------------------------

--
-- Table structure for table `data_alumni`
--

CREATE TABLE `data_alumni` (
  `nis` int(10) NOT NULL,
  `nama_lengkap` varchar(40) NOT NULL,
  `tempat_lahir` varchar(20) NOT NULL,
  `tanggal_lahir` date NOT NULL,
  `alamat` varchar(100) NOT NULL,
  `jenis_kelamin` varchar(12) NOT NULL,
  `agama` varchar(20) NOT NULL,
  `jurusan` varchar(10) NOT NULL,
  `tahun_lulus` varchar(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `data_alumni`
--

INSERT INTO `data_alumni` (`nis`, `nama_lengkap`, `tempat_lahir`, `tanggal_lahir`, `alamat`, `jenis_kelamin`, `agama`, `jurusan`, `tahun_lulus`) VALUES
(181910001, 'Ade Setiawan', 'Bandung', '2003-09-03', 'Kp. Cidawolong RT 02 RW 04 Desa Biru Kecamatan Majalaya Kabupaten Bandung, 40382', 'Laki - Laki', 'Islam', 'Akuntansi', '2021'),
(181910005, 'Ainanisa', 'Bandung', '2003-09-05', 'Kp. Bojong Gede Pojok RT 03 RW 13 Desa Sukamanah Kecamatan Solokan Jeruk Kabupaten Bandung, 40382', 'Perempuan', 'Islam', 'Akuntansi', '2021'),
(181910017, 'Anton Nurjaman', 'Bandung', '2003-03-11', 'Kp. Jongor RT 01 RW 14 Desa Serangmekar Kecamatan Ciparay Kabupaten Bandung', 'Laki - Laki', 'Islam', 'Akuntansi', '2021'),
(181910059, 'Dini Mulyanti', 'BANDUNG', '2002-08-12', 'Kp. Cidawolong RT 04 RW 10 Desa Biru Kecamatan Majalaya Kabupaten Bandung, 40382', 'Perempuan', 'Islam', 'Akuntansi', '2021'),
(181910066, 'Eliza Julianisa Sudarman', 'Bandung', '2003-07-22', 'Kp. Tawangsari RT 02 RW 16 Desa Sarimahi Kecamatan Ciparay Kabupaten Bandung, 40381', 'Perempuan', 'Islam', 'Akuntansi', '2021'),
(181910077, 'Fadli Fadiansah', 'Bandung', '2003-03-06', 'Kp. Sukasari RT 03 RW 07 Desa Drawati Kecamatan Paseh Kabupaten Bandung, 40383', 'Laki - Laki', 'Islam', 'Perbankan', '2021');

-- --------------------------------------------------------

--
-- Table structure for table `data_lowongan`
--

CREATE TABLE `data_lowongan` (
  `id_lowongan` int(11) NOT NULL,
  `nama_perusahaan` varchar(40) NOT NULL,
  `alamat` varchar(100) NOT NULL,
  `posisi` varchar(30) NOT NULL,
  `tgl_pembukaan` date NOT NULL,
  `tgl_penutupan` date NOT NULL,
  `kontak` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `data_lowongan`
--

INSERT INTO `data_lowongan` (`id_lowongan`, `nama_perusahaan`, `alamat`, `posisi`, `tgl_pembukaan`, `tgl_penutupan`, `kontak`) VALUES
(6, 'PT. Indomarco Prismatama', 'PT. Indomarco Prismatama Cabang Bandung\r\nJl. Jendral Ahmad Yani No. 806, Cicaheum, Kec. Sumur Bandun', 'Store Crew', '2022-01-11', '2022-01-31', '0857-2265-9000'),
(7, 'PT. Indomarco Prismatama', 'PT Indomarco Prismatama Cabang Bandung\r\nJl. Jendral Ahmad Yani No. 806, Cicaheum, Kec. Sumur Bandung', 'Video Editor', '2022-01-11', '2022-01-31', '0857-2265-9000'),
(9, 'Musik Positif', ' Jl. Arum Sari I, Babakan Sari, Kec. Kiaracondong, Kota Bandung, Jawa Barat 40283', 'Administrasi Umum', '2022-02-17', '2022-02-20', 'hrd.musicpositif@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `status`
--

CREATE TABLE `status` (
  `id_status` int(11) NOT NULL,
  `nis` int(10) NOT NULL,
  `nama_lengkap` varchar(40) NOT NULL,
  `jurusan` varchar(10) NOT NULL,
  `tahun_lulus` varchar(4) NOT NULL,
  `status` varchar(14) NOT NULL,
  `instansi` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `status`
--

INSERT INTO `status` (`id_status`, `nis`, `nama_lengkap`, `jurusan`, `tahun_lulus`, `status`, `instansi`) VALUES
(24, 181910001, 'Ade Setiawan', 'Akuntansi', '2021', 'Belum Bekerja', '-'),
(25, 181910005, 'Ainanisa', 'Akuntansi', '2021', 'Belum Bekerja', '-');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id_admin`);

--
-- Indexes for table `data_alumni`
--
ALTER TABLE `data_alumni`
  ADD PRIMARY KEY (`nis`);

--
-- Indexes for table `data_lowongan`
--
ALTER TABLE `data_lowongan`
  ADD PRIMARY KEY (`id_lowongan`);

--
-- Indexes for table `status`
--
ALTER TABLE `status`
  ADD PRIMARY KEY (`id_status`),
  ADD UNIQUE KEY `nis` (`nis`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id_admin` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `data_lowongan`
--
ALTER TABLE `data_lowongan`
  MODIFY `id_lowongan` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `status`
--
ALTER TABLE `status`
  MODIFY `id_status` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `status`
--
ALTER TABLE `status`
  ADD CONSTRAINT `status_ibfk_1` FOREIGN KEY (`nis`) REFERENCES `data_alumni` (`nis`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

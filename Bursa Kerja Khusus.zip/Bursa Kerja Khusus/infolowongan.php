<!DOCTYPE html>
<html lang="en">
<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>BURSA KERJA KHUSUS</title>

    <!-- Custom fonts for this template -->
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link
        href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="css/sb-admin-2.min.css" rel="stylesheet">

    <!-- Custom styles for this page -->
    <link href="vendor/datatables/dataTables.bootstrap4.min.css" rel="stylesheet">

</head>
 <div id="wrapper">

        <!-- Sidebar -->
        <ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">

            <!-- Sidebar - Brand -->
            <a class="sidebar-brand d-flex align-items-center justify-content-center" href="dashboard.php">
                <div class="sidebar-brand-icon rotate">
                   <i class="fas fa-user"></i>
                </div>
                <div class="sidebar-brand-text mx-3">SMK 1 LPPM RI MAJALAYA </div>
            </a>

            <!-- Divider -->
            

             <hr class="sidebar-divider my-0">
            <li class="nav-item">
                <a class="nav-link" href="infolowongan.php">

                    <i class="fas fa-fw fa-table"></i>
                    <span>Info Lowongan</span></a>
            </li>
            <hr class="sidebar-divider">
            <li class="nav-item">
                <a class="nav-link" href="login.php">
                    <i class="fas fa-sign-in-alt"></i>
                    <span>Login</span></a>
            </li>
            
            <hr class="sidebar-divider d-none d-md-block">

      
            <div class="text-center d-none d-md-inline">
                <button class="rounded-circle border-0" id="sidebarToggle"></button>
            </div>

        </ul>
            
       <hr class="sidebar-divider d-none d-md-block">

      
            <div class="text-center d-none d-md-inline">
                <button class="rounded-circle border-0" id="sidebarToggle"></button>
            </div>

        </ul>
         
 <div id="content-wrapper" class="d-flex flex-column">

          
            <div id="content">

           
                
                <div class="container-fluid">

                    <br>
                    <br>
                    <h1 class="h3 mb-2 text-gray-800">
                       <center>
                        Informasi Lowongan Pekerjaan
                    </center>
                    </h1>
                   

                    <br>
                    <br>
                    <div class="row">
                        <div class="col-md-6 col-sm-6 mb-3">
                            <div class="card">
                                <div class="card-body">
                                    <center><p>Open Recruitmen Music Positif</p>
                                    <p>Dibutuhkan Administrasi Umum</p></center>
                                    <p>Keterangan :</p>
                                    <p>1. Wanita / Pria Muslim Usia Maksimal 25 Tahun</p>
                                    <p>2. Diutamakan Belum Menikah</p>
                                    <p>3. Menguasai Ms. Excel, Word, PPT</p>
                                    <p>4. Pendidikan Minimal SMA/SMK</p>
                                    <p>5. Siap Bekerja Fulltime</p>
                                    <p>6. Ramah, Supel, dan bisa bekerja secara tim</p>
                                    <p>7. Sabar & Teliti Melakukan Pekerjaan serta mudah beradaptasi</p>
                                    <p>8. Bisa Bekerja Dibawah Deadline</p>
                                    <p>9. Berdomisili di Kota Bandung</p>
                                    <br>
                                    <p>Dibuka dari Tanggal 17 Februari - 20 Februari 2022</p>
                                    <p>Melampirkan Berkas dalam bentuk PDF : CV | SCAN KTP | IJAZAH TERAKHIR | FOTO DIRI TERBARU</p>
                                    <p>Email : hrd.musicpositif@gmail.com</p>
                                    <p>Subject : LAMARAN | (POSISI YANG INGIN DI APPLY)</p>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
                <!-- /.container-fluid -->

            </div>



 <a class="link" href="index.php">kembali</a>



<!-- Bootstrap core JavaScript-->
<script src="vendor/jquery/jquery.min.js"></script>
<script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- Core plugin JavaScript-->
<script src="vendor/jquery-easing/jquery.easing.min.js"></script>
<!-- Page level plugin JavaScript-->
<script src="vendor/chart.js/Chart.min.js"></script>
<script src="vendor/datatables/jquery.dataTables.js"></script>
<script src="vendor/datatables/dataTables.bootstrap4.js"></script>
<!-- Custom scripts for all pages-->
<script src="js/sb-admin.min.js"></script>
<!-- Custom scripts for this page-->
<script src="js/sb-admin-datatables.min.js"></script>
<script src="js/sb-admin-charts.min.js"></script>
</div>
</body>
</html>
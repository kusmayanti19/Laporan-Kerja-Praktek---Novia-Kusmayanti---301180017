<?php
include '../koneksi.php';
if(isset($_GET['id_status'])){
$hapus=mysqli_query($koneksi, "DELETE FROM status WHERE id_status='".$_GET['id_status']."'");
header("location:status.php");
}
?>
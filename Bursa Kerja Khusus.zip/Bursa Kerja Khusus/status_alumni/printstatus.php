<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>SMK 1 LPPM RI Majalaya</title>

    <!-- Custom fonts for this template -->
    <link href="../vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link
        href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet">

    <link href="../css/sb-admin-2.min.css" rel="stylesheet">

   <link href="../vendor/datatables/dataTables.bootstrap4.min.css" rel="stylesheet">

</head>

<body>

    <table style="width: 100%">
        <tr>
            <td align="center">
                <span style="line-height: 1.6; font-weight: bold;">
                    DATA ALUMNI SMK 1 LPPM RI MAJALAYA
                </span>
            </td>
        </tr>
    </table>
    <br>
    <br>

               
                    <div class="card shadow mb-4">
                        <div class="card-header py-3">
                           
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                    <thead>
                                        <tr>
                                            <th>No</th>
                                            <th>NIS</th>
                                            <th>Nama Lengkap</th>
                                            <th>Jurusan</th>
                                            <th>Tahun Lulus</th>
                                            <th>Status</th>
                                            <th>Instansi</th>
                                        </tr>
                                        </thead>
                  
                                    
 <?php
include '../koneksi.php';
$no=1;
$select=mysqli_query($koneksi, "SELECT * FROM status");
if(mysqli_num_rows($select) > 0){
while($hasil=mysqli_fetch_array($select)){
    ?>
    <tr>
    <td><?php echo $no++; ?></td>
    <td><?php echo $hasil['nis']; ?></td>
    <td><?php echo $hasil['nama_lengkap']; ?></td>
    <td><?php echo $hasil['jurusan'];?></td>
    <td><?php echo $hasil['tahun_lulus'];?></td>
    <td><?php echo $hasil['status']; ?></td>
    <td><?php echo $hasil['instansi'] ?></td>
  
     

</tr>
<?php
}}else{
    ?>
    

<?php } ?>

                                </table>
                            </div>
                        </div>
                    </div>

                </div>
                <!-- /.container-fluid -->

            </div>
        

        </div>
        <!-- End of Content Wrapper -->

    </div>
    <!-- End of Page Wrapper -->

    <script src="js/demo/datatables-demo.js"></script>
<script type="text/javascript">
       window.print();
   </script> 
</body>

</html>
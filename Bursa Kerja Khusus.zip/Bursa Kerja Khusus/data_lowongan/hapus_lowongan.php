<?php
include '../koneksi.php';
if(isset($_GET['id_lowongan'])){
$hapus=mysqli_query($koneksi, "DELETE FROM data_lowongan WHERE id_lowongan='".$_GET['id_lowongan']."'");
header("location:data_lowongan.php");
}
?>
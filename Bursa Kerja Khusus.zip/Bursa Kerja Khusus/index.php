<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>BURSA KERJA KHUSUS</title>

    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link
        href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet">


    <link href="css/sb-admin-2.min.css" rel="stylesheet">

    <link href="vendor/datatables/dataTables.bootstrap4.min.css" rel="stylesheet">

</head>

<body id="page-top">


    <div id="wrapper">
  <ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">
<br>
            <a class="sidebar-brand d-flex align-items-center justify-content-center" href="index.php">
                <div class="sidebar-brand-icon rotate">
                    <img src="hhh.png" class="img-thumbnail" alt="...">
                  
                </div>
                <div class="sidebar-brand-text mx-3">SMK 1 LPPM RI Majalaya</div>
            </a>
<br>
<br>
          
            <hr class="sidebar-divider my-0">
            <li class="nav-item">
                <a class="nav-link" href="infolowongan.php">

                    <i class="fas fa-fw fa-table"></i>
                    <span>Info Lowongan</span></a>
            </li>
            <hr class="sidebar-divider">
            <li class="nav-item">
                <a class="nav-link" href="login.php">
                    <i class="fas fa-sign-in-alt"></i>
                    <span>Login</span></a>
            </li>
            
            <hr class="sidebar-divider d-none d-md-block">

      
            <div class="text-center d-none d-md-inline">
                <button class="rounded-circle border-0" id="sidebarToggle"></button>
            </div>

        </ul>
       
        <div id="content-wrapper" class="d-flex flex-column">

          
            <div id="content">

           
                
                <div class="container-fluid">

                    <br>
                    <br>
                    <h1 class="h3 mb-2 text-gray-800">
                       <center>
                        BURSA KERJA KHUSUS
                       <br> 
                       SMK 1 LPPM RI MAJALAYA
                    </center>
                    </h1>
                   

                    <br>
                    <br>
                    <div class="card shadow mb-4">
                        
                        <div class="card-body">
                            <div class="table-responsive">
                                <?php
                               echo "VISI, MISI SMK 1 LPPM RI MAJALAYA :</p>";
                               echo "<p> 1. VISI</p>";
                               echo "<p>Jujur, unggul, tangguh, professional, kreatif dan inovatif.</p>";
                               echo"<p> 2. MISI</p>";
                               
                               echo "<p>a.   Meningkatkan keimanan dan ketaqwaan sehingga tercipta warga yang saleh dan lingkungan yang religious.</p>";
                               echo "b.  Mengoptimalkan pendayagunaan sumber daya manusia yang jujur, unggul, dan professional, sesuai dengan tuntunan dunia usaha dan industri";
                              
                               echo "<p>c.  Meningkatkan professionalism guru dan tata laksana yang berorientasi mutu dan keunggulan.</p>";
                               echo "<p>d.  Menciptakan hubungan yang harmonis dengan dunia usaha dan industri</p>";
                               echo "<p>e.  Meningkatkan budaya yang berpijak pada semangat kedisiplinan dan kekeluargaan</p>";
                               echo "<p>f.  Mengembangkan dan mengoptimalkan sarana dan prasarana agar terbentuk kompetensi dasar yang kuat.</p>";
                                ?>
                               
                            </div>
                        </div>
                       
                       
                    </div>

                </div>
                <!-- /.container-fluid -->

            </div>
            <!-- End of Main Content -->

            <!-- Footer -->
            <footer class="sticky-footer bg-white">
                <div class="container my-auto">
                    <div class="copyright text-center my-auto">
                        <span>Copyright &copy; SMK 1 LPPM RI Majalaya</span>
                    </div>
                </div>
            </footer>
            <!-- End of Footer -->

        </div>
        <!-- End of Content Wrapper -->

    </div>
    <!-- End of Page Wrapper -->

    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>

  

    <!-- Bootstrap core JavaScript-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Core plugin JavaScript-->
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Custom scripts for all pages-->
    <script src="js/sb-admin-2.min.js"></script>

    <!-- Page level plugins -->
    <script src="vendor/datatables/jquery.dataTables.min.js"></script>
    <script src="vendor/datatables/dataTables.bootstrap4.min.js"></script>

    <!-- Page level custom scripts -->
    <script src="js/demo/datatables-demo.js"></script>

</body>
</html>
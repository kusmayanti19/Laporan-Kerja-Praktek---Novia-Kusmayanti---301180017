 <?php
session_start();

include 'koneksi.php';

$username = $_POST['username'];
$password = $_POST['password'];
 
 
// menyeleksi data user dengan username dan password yang sesuai
$data = mysqli_query($koneksi,"select * from admin where username='$username' and password='$password'");
// menghitung jumlah data yang ditemukan
$cek = mysqli_num_rows($data);
 
// cek apakah username dan password di temukan pada database
if($cek > 0){
 
	// cek jika user login sebagai admin
	
 
		// buat session login dan username
		$_SESSION['username'] = $username;
		$_SESSION['status']="login";
		
		// alihkan ke halaman dashboard admin
		header("location:dashboard.php");
 
	
 
	}else{
 
		// alihkan ke halaman login kembali
		header("location:index.php?pesan=gagal");
	}	


 





?>

<?php
include '../koneksi.php';
if(isset($_GET['nis'])){
$hapus=mysqli_query($koneksi, "DELETE FROM data_alumni WHERE nis='".$_GET['nis']."'");
header("location:data_alumni.php");
}
?>
 




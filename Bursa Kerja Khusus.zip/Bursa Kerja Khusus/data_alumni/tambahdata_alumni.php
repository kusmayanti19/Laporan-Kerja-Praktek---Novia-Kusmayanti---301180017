
<?php
session_start(); 
include '../koneksi.php';
if(!isset($_SESSION['username'])){
    header("location:index.php");
}
?>

<!DOCTYPE html>
<html lang="en">
<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Tambah Data Alumni</title>

    <!-- Custom fonts for this template -->
    <link href="../vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link
        href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="../css/sb-admin-2.min.css" rel="stylesheet">

    <!-- Custom styles for this page -->
    <link href="../vendor/datatables/dataTables.bootstrap4.min.css" rel="stylesheet">

</head>

  <body>
<body id="page-top">


    <div id="wrapper">

        <ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">

            
            <a class="sidebar-brand d-flex align-items-center justify-content-center" href="index.html">
                <div class="sidebar-brand-icon rotate">
                   <i class="fas fa-user"></i>
                </div>
                <div class="sidebar-brand-text mx-3">SMK 1 LPPM RI MAJALAYA </div>
            </a>

            <!-- Divider -->
            <hr class="sidebar-divider my-0">

            <!-- Nav Item - Dashboard -->
            <li class="nav-item">
                <a class="nav-link" href="../dashboard.php">
                    <i class="fas fa-fw fa-tachometer-alt"></i>
                    <span>Dashboard</span></a>
            </li>
            <hr class="sidebar-divider">
            <li class="nav-item">
                <a class="nav-link" href="data_alumni.php">
                    <i class="fas fa-fw fa-table"></i>
                    <span>Data Alumni</span></a>
            </li>
            <hr class="sidebar-divider">
            <li class="nav-item">
                <a class="nav-link" href="../data_lowongan.php">
                    <i class="fas fa-fw fa-table"></i>
                    <span>Data Lowongan</span></a>
                    <hr class="sidebar-divider">
            <li class="nav-item">
                <a class="nav-link" href="../status.php">
                    <i class="fas fa-fw fa-table"></i>
                    <span>Status Alumni</span></a>
            </li>
            </li>
             <hr class="sidebar-divider">
            <li class="nav-item">
                <a class="nav-link" href="../logout.php">
                    <i class="fas fa-fw fa-table"></i>
                    <span>Logout</span></a>
            </li>
            <hr class="sidebar-divider d-none d-md-block">

      
            <div class="text-center d-none d-md-inline">
                <button class="rounded-circle border-0" id="sidebarToggle"></button>
            </div>

        </ul>
       
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

                <!-- Topbar -->
                <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">

                    <!-- Sidebar Toggle (Topbar) -->
                    <form class="form-inline">
                        <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
                            <i class="fa fa-bars"></i>
                        </button>
                    </form>

                    <!-- Topbar Search -->
                    

                    <!-- Topbar Navbar -->
                    <ul class="navbar-nav ml-auto">
                       

                       
                        <li class="nav-item dropdown no-arrow mx-1">
                            
                            <!-- Dropdown - Messages -->
                            <div class="dropdown-list dropdown-menu dropdown-menu-right shadow animated--grow-in"
                                aria-labelledby="messagesDropdown">
                               
                                <a class="dropdown-item d-flex align-items-center" href="#">
                                    <div class="dropdown-list-image mr-3">
                                        <img class="rounded-circle" src="img/undraw_profile_1.svg"
                                            alt="...">
                                        <div class="status-indicator bg-success"></div>
                                    </div>
                                   
                                </a>
                                <a class="dropdown-item d-flex align-items-center" href="#">
                                    <div class="dropdown-list-image mr-3">
                                        <img class="rounded-circle" src="img/undraw_profile_2.svg"
                                            alt="...">
                                        <div class="status-indicator"></div>
                                    </div>
                                    
                                </a>
                                <a class="dropdown-item d-flex align-items-center" href="#">
                                    <div class="dropdown-list-image mr-3">
                                        <img class="rounded-circle" src="img/undraw_profile_3.svg"
                                            alt="...">
                                        <div class="status-indicator bg-warning"></div>
                                    </div>
                                  
                                </a>
                                <a class="dropdown-item d-flex align-items-center" href="#">
                                    <div class="dropdown-list-image mr-3">
                                        <img class="rounded-circle" src="https://source.unsplash.com/Mv9hjnEUHR4/60x60"
                                            alt="...">
                                        <div class="status-indicator bg-success"></div>
                                    </div>
                                    
                                </a>
                               
                            </div>
                        </li>

                        <div class="topbar-divider d-none d-sm-block"></div>

                        <!-- Nav Item - User Information -->
                        <li class="nav-item dropdown no-arrow">
                            
                            <!-- Dropdown - User Information -->
                            
                        </li>

                    </ul>

                </nav>
    <div class="container" style="margin-top: 80px">
      <div class="row">
        <div class="col-md-8 offset-md-2">
          <div class="card">
            <div class="card-header">
              TAMBAH DATA ALUMNI
            </div>
            <div class="card-body">
              <form action="" method="POST">
                
                <div class="form-group">
                  <label>NIS</label>
                  <input type="text" name="nis" placeholder="Masukkan NIS" class="form-control" required>
                </div>

                <div class="form-group">
                  <label>Nama Lengkap</label>
                  <input type="text" name="nama_lengkap" placeholder="Masukkan Nama Lengkap" class="form-control" required>
                </div>
                <div class="form-group">
                  <label>Tempat Lahir</label>
                  <input type="text" name="tempat_lahir" placeholder="Masukkan Tempat Lahir" class="form-control" required>
                </div>
                <div class="form-group">
                  <label>Tanggal Lahir</label>
                  <input type="date" name="tanggal_lahir" placeholder="Masukkan Tanggal Lahir" class="form-control" required>
                </div>
                <div class="form-group">
                  <label>Alamat</label>
                  <textarea name="alamat" class="form-control" placeholder="Masukkan Alamat" rows="4"></textarea>
                </div>
                <div class="form-group">
                    <label class="mb-3">Jenis Kelamin</label>
                    <div class="custom-control custom-radio">
                      <input type="radio" name="jenis_kelamin" class="custom-control-input" id="Custom-ControlValidation2" value="Laki - Laki" required>
                      <label class="custom-control-label" for="Custom-ControlValidation2">Laki - Laki</label>
                    </div>
                    <div class="custom-control custom-radio mb-4">
                      <input type="radio" class="custom-control-input" id="Custom-Control-Validation3" name="jenis_kelamin" value="Perempuan" required>
                      <label class="custom-control-label" for="Custom-Control-Validation3">Perempuan</label>
                      <div class="invalid-feedback">Pilih Salah Satu Jenis Kelamin

                    </div>
                  </div>
                </div>
              <div class="form-group">
                <label>Agama</label>
                <select name="agama">
<option value="Islam">Islam</option>
<option value="Kristen">Kristen</option>
<option value="Hindu">Hindu</option>
<option value="Budha">Buddha</option>
<option value="Lainnya">Lainnya</option>
</select>
                  
                </div>
                <div class="form-group">
                  <label>Jurusan</label>
                     <select name="jurusan">
<option value="Akuntansi">Akuntansi</option>
<option value="Perbankan">Perbankan</option>
<option value="Pemasaran">Pemasaran</option>

</select>
                </div>


                <div class="form-group">
                  <label>Tahun Lulus</label>
                  <input type="text" name="tahun_lulus" placeholder="Masukkan Tahun Lulus" class="form-control" required>
                </div>


               <input type="submit" name="simpan" value="Simpan"></td>
              <button type="button" onclick="history.back();">Back</button>

<?php
//include 'koneksi.php';

if(isset($_POST['simpan'])){
$insert = mysqli_query($koneksi, "INSERT INTO data_alumni VALUES ('".$_POST['nis']."', '".$_POST['nama_lengkap']."',
'".$_POST['tempat_lahir']."' , '".$_POST['tanggal_lahir']."','".$_POST['alamat']."', '".$_POST['jenis_kelamin']."', '".$_POST['agama']."',
'".$_POST['jurusan']."', '".$_POST['tahun_lulus']."')");

if($insert){
   echo "berhasil disimpan";

}else{
    echo "gagal disimpan". mysqli_error($koneksi);
}
}                                      
?>

              </form>

            </div>
          </div>
        </div>
      </div>
    </div>



    <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>

  </body>
</html>
